#!/usr/bin/env python
import urllib2
import simplejson

# The request also includes the userip parameter which provides the end
# user's IP address. Doing so will help distinguish this legitimate
# server-side traffic from traffic which doesn't come from an end-user.
querys = ['Ford', 'Honda', 'Toyota', 'Lincoln', 'Dodge', 'Nissan', 'BMW', 'Jeep', 'Chevrolet', 'Audi']

urlbase = 'https://ajax.googleapis.com/ajax/services/search/web?v=1.0&userip=USERS-IP-ADDRESS&q='
starts = ['0', '4', '8']

for query in querys:
	fname = 'google/'query+".txt"
	fh = open(fname, 'w')
	for start in starts:
		url = urlbase + query + '&start=' + start
		request = urllib2.Request(url, None, {'Referer': 'http://www.usc.edu'})
		response = urllib2.urlopen(request)

		# Process the JSON string.
		results = simplejson.load(response)
		# now have some fun with the results...
		res = results['responseData']['results']
		
		for one in res:
			fh.write(one['url']+'\n')
