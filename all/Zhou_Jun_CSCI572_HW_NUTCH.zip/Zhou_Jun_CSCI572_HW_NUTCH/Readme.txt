Name: Jun Zhou
USCID: 8716374377

There are two methods to limit the crawl in the mirror, one is in regex-urlfilter.txt,
escape the links to other sites, like:
-^https?://(?!(fs.vsoeclassrooms.usc.edu/?)).*

The other method is to set db.ignore.external.links as true in nutch-site.xml. I have tried,
both work.

In the regex-normalize.txt, I use regex to do percent encoding of special characters in url.
For each of the spacial character, a regex is added. I asked in the nutch-user mailing list if
there is an easier way to do it, no body reply..

The result is like this:
Statistics for CrawlDb: data/crawldb/
TOTAL urls:     5298
retry 0:        5298
min score:      0.0
avg score:      5.483201E-4
max score:      1.0
status 2 (db_fetched):  5246
status 3 (db_gone):     52
CrawlDb statistics: done

I've checked the links with status 3, all of them are invalid links, most of them are the second or third pages
of a certain topic.

I only drop links of images/js etc, then accept anything, but still not able to get all the files. Don't know why.
Among the links above, there are 774 pdf files, using the pattern "/*/at_download/file".

