(function ($) {

var taxiData = [
//  new google.maps.LatLng(37.753837, -122.403172),
];
var pointArray;
var heatmap = null;

AjaxSolr.ResultWidget = AjaxSolr.AbstractWidget.extend({
  start: 0,


  beforeRequest: function () {

	taxiData = [];
	if (heatmap != null) {
		heatmap.setMap(null);
	}

    $(this.target).html($('<img>').attr('src', 'images/ajax-loader.gif'));
  },
  
  afterRequest: function () {
    $(this.target).empty();
	var output = '<h4>numFound: ' + this.manager.response.response.numFound + '</h4>';
    $(this.target).append(output);
    for (var i = 0, l = this.manager.response.response.docs.length; i < l; i++) {
      var doc = this.manager.response.response.docs[i];
      $(this.target).append(this.template(doc));

    }

	this.showmap();
  },

  showmap: function() {
	  pointArray = new google.maps.MVCArray(taxiData);
	  heatmap = new google.maps.visualization.HeatmapLayer({
		data: pointArray
	  });

	  heatmap.setMap(map);
	  heatmap.setOptions({radius: heatmap.get('radius') ? null : 30});
},

  template: function (doc) {
	var lat = Number(doc.latitude);
	var longi = Number(doc.longitude);
	//if (!isNaN(lat) && !isNaN(longi)) {
		taxiData.push(new google.maps.LatLng(lat, longi));
		//taxiData.push(new google.maps.LatLng(doc.attr_latitude, doc.attr_longtitude));
	//}
    var output = '<div><h4>' + doc.id + ": " + doc.address+ ", " + doc.latitude + ", "+ doc.longitude + '</h4></div>';
    return output;
  },
 
  init: function () {
    $(document).on('click', 'a.more', function () {
      var $this = $(this),
          span = $this.parent().find('span');

      if (span.is(':visible')) {
        span.hide();
        $this.text('more');
      }
      else {
        span.show();
        $this.text('less');
      }

      return false;
    });
  }
});

})(jQuery);
