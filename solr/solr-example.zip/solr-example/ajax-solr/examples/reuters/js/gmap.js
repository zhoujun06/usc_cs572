var map, pointarray, heatmap;

function initialize() {
  var mapOptions = {
    zoom: 4,
    center: new google.maps.LatLng(39.50, -98.35),
    //center: new google.maps.LatLng(37.774546, -122.433523),
    mapTypeId: google.maps.MapTypeId.SATELLITE
  };

  map = new google.maps.Map(document.getElementById('map-canvas'),
      mapOptions);

//  var pointArray = new google.maps.MVCArray(taxiData);

//  heatmap = new google.maps.visualization.HeatmapLayer({
//    data: pointArray
//  });

//  heatmap.setMap(map);
}

/*
function initialize() {
	var mapOptions = {
		center: new google.maps.LatLng(-34.397, 150.644),
		zoom: 8,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	};
	var map = new google.maps.Map(document.getElementById("map-canvas"),
			mapOptions);
}
*/
google.maps.event.addDomListener(window, 'load', initialize);
